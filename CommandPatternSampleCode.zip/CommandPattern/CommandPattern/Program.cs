﻿using CommandPattern.Services;

namespace CommandPattern
{
	class Program
	{
		public static void Main(string[] args)
		{
			CompositeCommand command = new CompositeCommand();
			command.Add(new Command1());
			command.Add(new Command2());

			Publisher publisher = new Publisher(command);

			publisher.setState("Set");

			publisher.setState("Unset");
		}
	}
}
