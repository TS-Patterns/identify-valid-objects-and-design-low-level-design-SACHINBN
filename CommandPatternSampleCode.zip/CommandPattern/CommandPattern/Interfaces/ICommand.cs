﻿namespace CommandPattern.Interfaces
{
	public interface ICommand
	{
		void Publish();
	}
}
