﻿namespace CommandPattern.Interfaces
{
	public interface IPublisher
	{
		string GetState();
	}
}
