﻿using CommandPattern.Interfaces;

namespace CommandPattern.Services
{
	public class Command1 : ICommand
	{
		public void Publish()
		{
			Subscriber1 subscriber1 = new Subscriber1(new Publisher(new Command1()));
			subscriber1.Subscribe();
		}
	}
}
