﻿using CommandPattern.Interfaces;
using System;

namespace CommandPattern.Services
{
	public class Subscriber1
	{
		private IPublisher _publisher;

		public Subscriber1(IPublisher publisher)
		{
			_publisher = publisher;
		}
		public void Subscribe()
		{
			Console.WriteLine("State updated to {0} subscribed from Subscriber1", _publisher.GetState());
			Console.ReadKey();
		}
	}
}
