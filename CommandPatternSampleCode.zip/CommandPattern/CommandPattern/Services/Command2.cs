﻿using CommandPattern.Interfaces;

namespace CommandPattern.Services
{
	public class Command2 : ICommand
	{
		public void Publish()
		{
			Subscriber2 subscriber2 = new Subscriber2(new Publisher(new Command2()));
			subscriber2.Subscribe();
		}
	}
}
