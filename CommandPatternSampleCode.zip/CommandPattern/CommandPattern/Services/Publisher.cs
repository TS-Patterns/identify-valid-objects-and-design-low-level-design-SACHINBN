﻿using CommandPattern.Interfaces;

namespace CommandPattern.Services
{
	public class Publisher : IPublisher
	{
		private static string _state;
		private ICommand _command;

		public Publisher(ICommand command)
		{
			_command = command;
		}

		public string GetState()
		{
			return _state;
		}

		public void setState(string state)
		{
			_state = state;
			_command.Publish();
		}
	}
}
