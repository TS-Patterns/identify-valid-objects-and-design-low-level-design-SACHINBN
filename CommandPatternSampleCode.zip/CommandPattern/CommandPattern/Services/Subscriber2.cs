﻿using CommandPattern.Interfaces;
using System;

namespace CommandPattern.Services
{
	public class Subscriber2
	{
		private IPublisher _publisher;

		public Subscriber2(IPublisher publisher)
		{
			_publisher = publisher;
		}
		public void Subscribe()
		{
			Console.WriteLine("State updated to {0} subscribed from Subscriber2", _publisher.GetState());
			Console.ReadKey();
		}
	}
}
