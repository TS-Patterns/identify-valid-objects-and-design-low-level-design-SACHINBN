﻿using CommandPattern.Interfaces;
using System.Collections.Generic;

namespace CommandPattern.Services
{
	public class CompositeCommand : ICommand
	{
		protected List<ICommand> _commands = new List<ICommand>();

		public void Add(ICommand command)
		{
			_commands.Add(command);
		}

		public void Remove(ICommand command)
		{
			_commands.Remove(command);
		}

		public void Publish()
		{
			foreach(ICommand command in _commands)
			{
				command.Publish();
			}
		}
	}
}
